# App Analyzer — Implementation Plan

**Status:** Plan only (no execution). Approve then run implementation separately.

**Goal:** New page "App Analyzer" with category tabs (Website, Web App, SaaS, PaaS, etc.). In each tab, run audits (e.g. SEO, Legal/Impressum) against a given URL.

---

## 1. High-level architecture

- **Route:** `/app-analyzer`
- **Page:** Single Next.js page that renders one organism: `AppAnalyzerPageContent`.
- **Tabs:** One tab per software category (Website, Web App, SaaS, PaaS; optionally Mobile App, Desktop App later). Use existing `Tabs` from `src/components/ui/tabs.tsx`.
- **Per-tab content:** URL input, audit type selector (e.g. SEO, Legal/Impressum), "Run audit" action, results panel (pass/fail + details).
- **Backend:** Fetching the target URL must work in both Tauri (desktop) and browser. Tauri has no HTTP client today; browser `fetch(url)` hits CORS for cross-origin. So:
  - **Tauri:** New command that fetches URL (add `reqwest` to `Cargo.toml`) and returns `{ statusCode, headers, body }` (or truncated body for large pages).
  - **Browser fallback:** Next.js API route that proxies the fetch (e.g. `POST /api/app-analyzer/fetch` with `{ url }`) and returns the same shape.
- **Audit logic:** Implemented in the frontend (or a shared TS module) so it stays portable: given HTML + headers, run heuristics (SEO: meta description, title, og tags, h1; Legal: presence of Impressum/Privacy/Legal links or text). No new backend commands for “run audit” — only “fetch URL” is backend; “run audit” = fetch then run checks in TS.

---

## 2. Component structure (visual tree)

```
AppAnalyzerPageContent (organism)
├── Breadcrumb  [Dashboard → App Analyzer]
├── SingleContentPage (or PageWithHeader)
│   ├── Title: "App Analyzer", description, icon (e.g. ScanSearch)
│   └── Tabs (shadcn Tabs)
│       ├── TabsList
│       │   ├── TabsTrigger "Website"
│       │   ├── TabsTrigger "Web App"
│       │   ├── TabsTrigger "SaaS"
│       │   ├── TabsTrigger "PaaS"
│       │   └── (optional later: Mobile App, Desktop App)
│       └── TabsContent per category
│           └── AppAnalyzerCategoryPanel (molecule) — shared for all categories
│               ├── URL input (Input) + optional "Open in browser" (Button)
│               ├── Audit type selector (Select or Checkbox group): e.g. SEO, Legal/Impressum, (later: Performance, A11y)
│               ├── Button "Run audit"
│               └── AuditResults (molecule)
│                   ├── Loading state (Skeleton or Spinner)
│                   ├── Error state (Alert)
│                   └── Result list: each check (name, status pass/fail/warn, message, optional link to spec)
```

**Reuse:** `SingleContentPage`, `Breadcrumb`, `Tabs`, `TabsList`, `TabsTrigger`, `TabsContent`, `Button`, `Input`, `Card`, `Alert`, `Skeleton` from existing UI. No new shadcn components required.

---

## 3. Data flow and types

- **Fetch URL (backend):**
  - **Tauri command:** `fetch_url(url: String) -> Result<FetchUrlResult, String>`.
  - **Type:** `FetchUrlResult = { statusCode: number, headers: Record<string, string>, body: string }` (body may be truncated to e.g. 500 KB to avoid huge payloads).
  - **API route (browser):** `POST /api/app-analyzer/fetch` body `{ url: string }`, returns same `FetchUrlResult` or `{ error: string }`.
- **Audit (frontend only):**
  - **Input:** `FetchUrlResult` (or error).
  - **Output:** `AuditResult = { auditType: 'seo' | 'legal', checks: { id: string, name: string, status: 'pass' | 'fail' | 'warn', message: string, detail?: string }[] }`.
  - **SEO checks (example):** has `<title>`, has meta description, has og:title/og:description, has exactly one `<h1>`, etc.
  - **Legal/Impressum checks (example):** page or linked page contains "Impressum" or "Legal" or "Privacy" or "Terms", or links to /impressum, /legal, /privacy (heuristic).

Types should live in `src/types/app-analyzer.ts` (new file).

---

## 4. Files to create or modify

### 4.1 New files

| File | Purpose |
|------|---------|
| `src/app/app-analyzer/page.tsx` | Next.js page: render `AppAnalyzerPageContent`. |
| `src/components/organisms/AppAnalyzerPageContent.tsx` | Main organism: Breadcrumb, SingleContentPage, Tabs, category tabs and triggers. |
| `src/components/molecules/AppAnalyzer/AppAnalyzerCategoryPanel.tsx` | URL input, audit type selector, Run audit button, and AuditResults. |
| `src/components/molecules/AppAnalyzer/AuditResults.tsx` | Display list of checks (pass/fail/warn) with messages. |
| `src/types/app-analyzer.ts` | Types: `FetchUrlResult`, `AuditResult`, `AuditCheck`, audit type union. |
| `src/lib/app-analyzer-fetch.ts` | Dual-mode fetch: `invoke('fetch_url', { url })` in Tauri, else `fetch('/api/app-analyzer/fetch', { method: 'POST', body: JSON.stringify({ url }) })`. |
| `src/lib/app-analyzer-audit.ts` | Pure functions: `runSeoAudit(html, headers)`, `runLegalAudit(html, headers)` returning `AuditResult`. |
| `src/app/api/app-analyzer/fetch/route.ts` | Next.js route: validate URL, server-side fetch, return `FetchUrlResult` or error. |
| `src-tauri/src/lib.rs` | Add `#[tauri::command] fn fetch_url(url: String) -> Result<FetchUrlResult, String>` and register in `generate_handler![]`. |
| `.cursor/adr/0210-app-analyzer-page.md` | ADR for this feature. |

### 4.2 Files to modify

| File | Change |
|------|--------|
| `src/components/organisms/SidebarNavigation.tsx` | Add nav item under Tools: `{ href: "/app-analyzer", label: "App Analyzer", icon: ScanSearch }`. Import `ScanSearch` from lucide-react. |
| `src-tauri/Cargo.toml` | Add dependency `reqwest = { version = "0.12", features = ["blocking", "json"] }` (or equivalent; blocking is enough for a simple GET). |
| `src-tauri/src/lib.rs` | Implement `fetch_url` (parse URL, set User-Agent, GET request, read body with size limit, return struct with statusCode, headers, body). Register command. |

**Code references:**

- **Tabs usage:** `src/components/organisms/ProjectDetailsPageContent.tsx` (Tabs, TabsList, TabsTrigger, TabsContent) and `src/components/molecules/LayoutAndNavigation/ThreeTabLayout.tsx`.
- **Breadcrumb + SingleContentPage:** `src/components/organisms/TechnologiesPageContent.tsx` (Breadcrumb items, SingleContentPage with title/description/icon/layout).
- **Sidebar nav:** `src/components/organisms/SidebarNavigation.tsx` — `getNavItems()` → `toolsNavItems` array; add one entry.
- **invoke + isTauri:** `src/lib/tauri.ts`; dual-mode fetch pattern in `src/components/molecules/TabAndContentSections/DatabaseDataTabContent.tsx` (readFileContent: invoke vs fetch).
- **API route pattern:** `src/app/api/data/files/route.ts` or any `src/app/api/data/*/route.ts` for GET; for POST with body see `src/app/api/check-openai/route.ts` or similar.
- **Register Tauri command:** `src-tauri/src/lib.rs` — search for `tauri::generate_handler!` and add `fetch_url` to the list.

---

## 5. Implementation steps (order)

1. **Types and fetch layer**
   - Add `src/types/app-analyzer.ts` with `FetchUrlResult`, `AuditResult`, `AuditCheck`, audit type.
   - Add `src/lib/app-analyzer-fetch.ts` with `fetchUrlForAudit(url: string)` that uses invoke in Tauri and fetch to `/api/app-analyzer/fetch` in browser.

2. **Backend: Tauri**
   - Add `reqwest` to `src-tauri/Cargo.toml`.
   - In `lib.rs`, implement `fetch_url(url: String)` (validate URL scheme http/https, GET with timeout and body size limit, collect headers, return serializable struct). Register in `generate_handler![]`.

3. **Backend: API route**
   - Create `src/app/api/app-analyzer/fetch/route.ts`: parse POST body `{ url }`, validate URL, fetch from server, return same shape as Tauri (statusCode, headers, body with limit).

4. **Audit logic**
   - Add `src/lib/app-analyzer-audit.ts`: `runSeoAudit(html, headers)` and `runLegalAudit(html, headers)` (parse HTML with regex or DOM parser if available in Node/browser; run checks; return `AuditResult`).

5. **UI: molecules**
   - `AuditResults.tsx`: props `result: AuditResult | null`, `loading: boolean`, `error: string | null`; render list of checks with status icons and messages.
   - `AppAnalyzerCategoryPanel.tsx`: URL state, audit type state (multi-select or single), "Run audit" handler (call fetch then audit), pass result to `AuditResults`.

6. **UI: organism and page**
   - `AppAnalyzerPageContent.tsx`: Breadcrumb, SingleContentPage, Tabs with category triggers and one `AppAnalyzerCategoryPanel` per TabsContent (or one shared panel keyed by category if UX is identical).
   - `src/app/app-analyzer/page.tsx`: default export rendering `AppAnalyzerPageContent`.

7. **Navigation**
   - In `SidebarNavigation.tsx`, add "App Analyzer" to `toolsNavItems` with `href: "/app-analyzer"`, `icon: ScanSearch`.

8. **Optional: command palette**
   - Add "Go to App Analyzer" (or "Open App Analyzer") to command palette entries in `src/components/shared/CommandPalette.tsx` (pattern: other "Go to X" entries).

9. **Documentation and ADR**
   - Add `.cursor/adr/0210-app-analyzer-page.md` (context, decision, consequences).
   - Optionally add a short note in `.cursor/app-analyzer/plan.md` that implementation is done (after execution).

---

## 6. Category-specific audits (initial vs later)

- **Initial:** All categories can share the same audit set (SEO + Legal/Impressum). Category tabs mainly change labeling and possibly which audits are selected by default (e.g. Website defaults to SEO + Legal; PaaS might add "Status page" later).
- **Later:** Category-specific checks (e.g. SaaS: login/signup links; PaaS: API docs link; Mobile: store links) can be added to `app-analyzer-audit.ts` and selected by category in the panel.

---

## 7. Security and robustness

- **URL validation:** Allow only `http` and `https`; reject `file://`, `javascript:`, etc. (both in Tauri and in API route). Sanitize and limit URL length.
- **Time and size limits:** Tauri and API route should use a short timeout (e.g. 15 s) and cap response body (e.g. 500 KB) to avoid DoS.
- **User-Agent:** Set a identifiable User-Agent for the server-side fetch so sites can see it’s an audit tool.

---

## 8. Testing (for later)

- Unit tests for `runSeoAudit` and `runLegalAudit` with fixture HTML.
- E2E: open App Analyzer, enter URL, run audit, see results (optional; can be added after initial implementation).

---

**Next step:** User approves this plan; then run implementation (e.g. by assigning steps to Frontend and Backend agents or executing step-by-step).
