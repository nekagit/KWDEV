# Convert Milestone to Tickets

You are breaking down a **single milestone** into **actionable tickets**. Each ticket should be a concrete, implementable task.

---

## Input

1. Read the milestones from `.cursor/worker/milestones-output.md`
2. Focus on the **current milestone** specified in the prompt context
3. Reference the original idea in `.cursor/worker/idea-analysis-output.md` for context

---

## Step 1 — Understand the Milestone

Parse the milestone and understand:
1. What is the deliverable?
2. What files need to be created or modified?
3. What are the discrete units of work?

---

## Step 2 — Break Into Tickets

Create **2-5 tickets** per milestone that:
- Each represent a single, focused task
- Can be completed by one agent run
- Have clear acceptance criteria
- Are ordered by dependency (foundational first)

Good ticket examples:
- "Create data model for X"
- "Add API endpoint for Y"
- "Build UI component for Z"
- "Integrate X with Y"
- "Add validation and error handling"

Bad ticket examples (too vague):
- "Implement the feature"
- "Make it work"
- "Fix issues"

---

## Step 3 — Output Tickets

**IMPORTANT:** Write your tickets to `.cursor/worker/tickets-output.md` in this exact format:

```markdown
# Tickets Output

## Milestone: [Milestone name]

### Ticket 1: [Clear, actionable title]
**Description:** [Specific description of what to implement, which files to create/modify]
**Priority:** P1
**Acceptance Criteria:**
- [ ] [Specific, testable criterion]
- [ ] [Another criterion]

### Ticket 2: [Clear, actionable title]
**Description:** [Specific description]
**Priority:** P1
**Acceptance Criteria:**
- [ ] [Criterion]
- [ ] [Criterion]

### Ticket 3: [Clear, actionable title]
**Description:** [Specific description]
**Priority:** P2
**Acceptance Criteria:**
- [ ] [Criterion]

[Continue for all tickets...]
```

---

## Priority Guidelines

- **P1** — Core functionality, must be done first
- **P2** — Important but can wait for P1s
- **P3** — Nice to have, polish items

---

## Guidelines

- **2-5 tickets** per milestone is the target
- Each ticket should be completable in one agent session
- Be specific about files and implementation details
- Include clear acceptance criteria
- Output MUST be written to `.cursor/worker/tickets-output.md`

*This prompt is used by idea-driven night shift to create actionable work items.*
