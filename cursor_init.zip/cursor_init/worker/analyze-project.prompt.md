# Analyze Project — Find Next Major Feature

You are in **idea-driven night shift mode**. Your job is to analyze this project and identify the **next major feature** that should be built.

---

## Step 1 — Understand the Project

Read and understand:
1. **Project structure** — Browse key directories, understand the architecture
2. **Existing features** — What's already implemented?
3. **Documentation** — Check `.cursor/README.md`, `.cursor/1. project/`, and any ADRs
4. **Recent changes** — Look at git log to see what was recently built
5. **Ideas backlog** — Check `.cursor/0. ideas/` for any documented ideas

---

## Step 2 — Identify Gaps

Look for:
- Features mentioned in docs but not implemented
- Natural extensions to existing functionality
- Missing integrations or capabilities
- User-facing improvements that would add real value
- Performance or UX enhancements

**Not eligible:**
- Bug fixes (those are tickets, not features)
- Refactoring without new behavior
- Test coverage improvements
- Documentation-only changes

---

## Step 3 — Choose ONE Feature

Select the **single most impactful feature** that:
1. Adds real, user-visible value
2. Can be broken into clear milestones
3. Fits the project's architecture and conventions
4. Is substantial enough to warrant multiple tickets

---

## Step 4 — Output Your Analysis

**IMPORTANT:** Write your analysis to `.cursor/worker/idea-analysis-output.md` in this exact format:

```markdown
# Idea Analysis Output

## Project Summary
[2-3 sentences about what this project does]

## Current State
[What features exist, what's been recently built]

## Next Feature Idea

**Title:** [Clear, concise feature name]

**Description:** [Detailed description of the feature - 2-4 sentences explaining what it does and how users will interact with it]

**Rationale:** [Why this feature is needed now, what problem it solves, why it's the right next step]

## Implementation Considerations
[Brief notes on how this might be implemented, what parts of the codebase it touches]
```

---

## Conventions

- Be specific — vague ideas like "improve UX" are not acceptable
- Think like a product manager — what would users actually want?
- Consider scope — the feature should be implementable in multiple milestones
- Output MUST be written to `.cursor/worker/idea-analysis-output.md`

*This prompt is used by idea-driven night shift to automatically discover features.*
