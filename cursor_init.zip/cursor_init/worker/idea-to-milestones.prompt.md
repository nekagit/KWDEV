# Convert Idea to Milestones

You are breaking down a feature idea into **multiple milestones**. Each milestone should be a distinct, shippable increment of the feature.

---

## Input

Read the idea from `.cursor/worker/idea-analysis-output.md` — this contains the feature title, description, and rationale.

---

## Step 1 — Understand the Feature

Parse the idea and understand:
1. What is the end goal?
2. What are the major components?
3. What depends on what?
4. What can be shipped independently?

---

## Step 2 — Break Into Milestones

Create **3-6 milestones** that:
- Each deliver incremental value
- Build on each other logically
- Are roughly equal in scope
- Can each be completed in 1-3 tickets

Good milestone examples:
- "Core data model and API" → "UI components" → "Integration and polish"
- "Backend foundation" → "Basic UI" → "Advanced features" → "Testing and docs"

---

## Step 3 — Output Milestones

**IMPORTANT:** Write your milestones to `.cursor/worker/milestones-output.md` in this exact format:

```markdown
# Milestones Output

## Feature: [Feature title from idea]

### Milestone 1: [Name]
**Description:** [What this milestone achieves, what will be shippable after it's done]
**Depends On:** [None, or list previous milestone numbers]

### Milestone 2: [Name]
**Description:** [What this milestone achieves]
**Depends On:** [Milestone 1]

### Milestone 3: [Name]
**Description:** [What this milestone achieves]
**Depends On:** [Milestone 2]

[Continue for all milestones...]
```

---

## Guidelines

- **3-6 milestones** is the target range
- Each milestone should be completable in a focused work session
- Earlier milestones should be foundational (data, APIs, core logic)
- Later milestones should be user-facing (UI, integration, polish)
- Output MUST be written to `.cursor/worker/milestones-output.md`

*This prompt is used by idea-driven night shift to structure feature development.*
